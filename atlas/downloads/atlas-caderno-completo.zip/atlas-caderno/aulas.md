# Atlas · Caderno de Dados e BI
Atualizado em 19/10/2026
Material original de estudo. Referências externas indicadas por capítulo.

## Semana 1 · Fundamentos e organização
Uma análise confiável começa antes do gráfico. Você precisa reconhecer o que cada linha representa, em qual unidade os valores estão e de onde vieram. No negócio de grãos, sacos, quilogramas e reais respondem a perguntas diferentes. Nesta semana, transforme os arquivos do kit em uma base organizada e confira uma conta que você consegue explicar de cabeça.

### Pedido, item e cadastro
O pedido representa a negociação: cliente, data, status e frete. Cada item representa um produto desse pedido. Um pedido pode aparecer várias vezes quando você consulta os itens. Clientes e produtos são cadastros, com uma linha por entidade. Antes de somar, escreva o significado de uma linha de cada tabela.

### Importação com tipos corretos
No kit, o CSV usa ponto e vírgula entre colunas, vírgula decimal e datas no formato ano-mês-dia. Importe por Dados → De Texto/CSV e confira a localidade. Preserve identificadores como códigos; um código não é uma quantidade para somar. Valide três linhas depois da importação, incluindo um preço com centavos.

### Unidades que fecham
A quantidade de sacos multiplicada pelo peso de cada saco resulta em quilogramas. Multiplique esse peso pelo preço por kg para chegar à receita. A embalagem padrão do cadastro é uma referência: se o item registra outro peso, a conta usa o peso efetivamente registrado no item.

### Exemplo
```Excel
Peso_kg: =[@qtd_sacos]*[@peso_saco_kg]
Receita_R$: =[@Peso_kg]*[@preco_kg]
```
Exemplo didático: 10 sacos × 25 kg = 250 kg. Com preço de R$ 1,30/kg, a receita é R$ 325,00. Se o saco mudar para 50 kg, a mesma quantidade de sacos passa a representar 500 kg. Primeiro confira a unidade, depois compare os valores.
### Prática
1. Importe os seis CSV de treino em abas separadas e transforme os intervalos em tabelas.
2. Escreva um dicionário com nome, significado, tipo e unidade dos campos.
3. Calcule o exemplo de 10 sacos e depois teste 12 sacos de 50 kg.
4. Reconcilie a quantidade de linhas: 16 clientes, 4 produtos, 360 pedidos e 540 itens.
### Erros frequentes
- Abrir o CSV por duplo clique e aceitar preços interpretados como texto.
- Somar sacos e apresentar o resultado como kg.
- Modificar o arquivo original sem guardar uma cópia.
### Referências
Excel: fórmulas, tabelas e análise - Microsoft Support — https://support.microsoft.com/pt-br/excel/

## Semana 2 · Excel para perguntas de negócio
As fórmulas precisam continuar corretas quando entram novas linhas. Nesta semana você vai traduzir regras do negócio em condições, buscas e resumos. Comece pela pergunta: quais registros entram no cálculo? Só depois escolha a função. Uma fórmula curta com uma regra explícita vale mais que uma fórmula longa que você não consegue explicar.

### Condições e critérios
SE escolhe um resultado a partir de uma condição. SOMASES soma apenas as linhas que atendem aos critérios; CONT.SES conta essas linhas. Use exatamente os status e as datas registrados. No kit, faturamento considera apenas Faturado: pedido em aberto não vira receita só por existir na base.

### Buscas pela chave
PROCX procura um identificador e devolve a informação correspondente. A chave precisa ser confiável: nomes podem se repetir ou mudar. Trate a ausência com uma mensagem explícita e investigue a causa. A disponibilidade de PROCX depende da versão do Excel; se necessário, use uma alternativa com correspondência exata.

### Referências que acompanham a tabela
Referências estruturadas como Itens[receita] acompanham o crescimento da tabela. Em fórmulas comuns, entenda a diferença entre A1, $A$1, A$1 e $A1 antes de arrastar. Formatar como moeda muda a aparência, não corrige um valor importado como texto.

### Exemplo
```Excel
=SOMASES(Vendas[receita];Vendas[status];"Faturado")
=CONT.SES(Pedidos[status];"Faturado")
=PROCX([@id_cliente];Clientes[id_cliente];Clientes[nome];"Chave não encontrada")
```
Suponha três pedidos: Faturado R$ 325, Faturado R$ 650 e Cancelado R$ 400. A receita considerada é R$ 975. O ticket desses pedidos é R$ 487,50, desde que cada linha da tabela Pedidos represente um pedido distinto.
### Prática
1. Crie as colunas peso e receita em uma tabela de itens.
2. Traga o cliente e o status usando as chaves e confira três resultados manualmente.
3. Some a receita por status e conte pedidos na tabela de pedidos.
4. Adicione uma linha de teste, valide a expansão da fórmula e remova apenas essa linha de teste.
### Erros frequentes
- Usar busca aproximada sem intenção.
- Substituir toda busca não encontrada por zero e esconder a falha.
- Contar itens como se fossem pedidos.
### Referências
Excel: fórmulas, tabelas e análise - Microsoft Support — https://support.microsoft.com/pt-br/excel/

## Semana 3 · Limpeza e primeira avaliação
Limpar dados significa aplicar decisões justificáveis, preservando a possibilidade de conferir o que mudou. Você vai praticar em um cadastro com problemas conhecidos e entregar um registro das correções. Não basta obter um total bonito: outra pessoa deve conseguir repetir o processo e chegar ao mesmo resultado.

### Identificar antes de excluir
No arquivo clientes_para_limpeza.csv existem 19 linhas: duas duplicatas por chave e uma linha sem identificador. O resultado esperado é 16 clientes válidos. Chave repetida não significa que duas linhas sejam sempre intercambiáveis. Compare os demais atributos e documente qual registro foi mantido.

### Quarentena e padronização
Uma linha sem ID deve ficar separada para investigação. Não invente um código para fazer a importação passar. Remova espaços indevidos e padronize a UF com uma regra consistente. Guarde uma cópia da origem e um registro das linhas rejeitadas para explicar a diferença entre entrada e saída.

### Resumo que pode ser conferido
Use uma tabela dinâmica para resumir receita por produto e mês. Confira o filtro de status e atualize a tabela quando a fonte mudar. O total geral precisa bater com a soma da tabela tratada. Se houver diferença, procure filtro, tipo incorreto, intervalo incompleto ou duplicação.

### Exemplo
```Reconciliação
19 linhas de entrada
− 2 ocorrências duplicadas
− 1 registro sem chave, em quarentena
= 16 clientes válidos
```
Esse balanço de linhas é uma evidência simples de qualidade. Ele não substitui a validação dos atributos: depois de fechar a contagem, confira se os 16 IDs são distintos e se cidade e UF continuam coerentes.
### Prática
1. Identifique duplicatas por id_cliente sem alterar a origem.
2. Separe a linha sem chave e escreva o motivo.
3. Padronize os atributos e registre as transformações.
4. Crie o resumo de vendas, reconcilie o total e refaça uma fórmula sem consultar o modelo.
### Erros frequentes
- Remover duplicatas pelo nome, juntando clientes diferentes.
- Apagar linhas rejeitadas sem registrar a decisão.
- Usar a tabela dinâmica sem atualizar a origem.
### Referências
Excel: fórmulas, tabelas e análise - Microsoft Support — https://support.microsoft.com/pt-br/excel/

## Semana 4 · SQL: começar do básico
SQL permite fazer perguntas a tabelas de forma reproduzível. Você vai começar com seleção de colunas, filtros e ordenação. O laboratório do Atlas usa SQLite; os scripts do kit são para SQL Server. A lógica relacional é parecida, mas algumas funções e comandos mudam entre os dois ambientes.

### Uma pergunta por consulta
SELECT escolhe as colunas e FROM define a tabela. Use nomes explícitos para saber o que está retornando. O asterisco ajuda a explorar uma base pequena, mas uma entrega fica mais clara com as colunas necessárias e aliases que expliquem os resultados.

### Filtro antes do resumo
WHERE restringe as linhas. Combine regras com AND e OR e use parênteses quando misturar condições. Datas ISO permitem uma leitura clara no laboratório. Para filtrar um mês com horários, use início inclusivo e início do mês seguinte exclusivo.

### Ordenação e dialeto
ORDER BY define a sequência do resultado. Sem ordenação, não dependa da posição das linhas. SQLite limita resultados com LIMIT; SQL Server usa TOP ou outras construções próprias. Não confunda diferença de sintaxe com erro na regra de negócio.

### Exemplo
```SQLite
SELECT id_pedido, data_pedido, status
FROM pedidos
WHERE status = 'Faturado'
  AND data_pedido >= '2026-06-01'
  AND data_pedido < '2026-07-01'
ORDER BY data_pedido, id_pedido
LIMIT 10;
```
A consulta mostra até dez pedidos faturados de junho, em ordem de data e ID. O limite não calcula a quantidade total do mês. Para contar todos, use COUNT(*) sem LIMIT sobre o conjunto filtrado.
### Prática
1. Explore uma amostra das seis tabelas.
2. Selecione somente pedidos Faturados.
3. Aplique uma faixa de datas e confira as bordas.
4. Adapte LIMIT 10 para SELECT TOP (10) ao praticar no SQL Server.
### Erros frequentes
- Usar o limite da amostra como se fosse o total da base.
- Esperar uma ordem estável sem ORDER BY.
- Copiar funções de SQL Server para SQLite sem adaptação.
### Referências
SQL básico: Consultar e modificar dados com Transact-SQL — https://learn.microsoft.com/pt-br/training/paths/get-started-querying-with-transact-sql/
SQLite: sintaxe de SELECT — https://www.sqlite.org/lang_select.html

## Semana 5 · SQL: agregações e regras
Agregações resumem muitas linhas, mas só fazem sentido quando o agrupamento e o denominador estão corretos. Você vai contar pedidos, resumir valores e tratar ausências. Sempre declare se está calculando uma soma, uma média por linha ou uma razão entre totais.

### Agrupar sem perder a regra
GROUP BY produz um resultado por combinação de valores. WHERE filtra antes do agrupamento; HAVING filtra os grupos depois da agregação. Se você quer status com mais de 20 pedidos, primeiro forme os grupos e depois aplique a regra da contagem.

### Ausência não é zero
NULL representa ausência. Compare com IS NULL ou IS NOT NULL. COUNT(*) conta linhas; COUNT(coluna) ignora NULL nessa coluna. COALESCE permite escolher um substituto, mas transformar toda ausência em zero pode inventar uma informação que a base não contém.

### Médias e proporções
O preço médio por kg deve considerar o peso vendido. Uma venda de 100 kg a R$ 1,00 e outra de 900 kg a R$ 2,00 resultam em R$ 1,90/kg. A média simples de R$ 1,00 e R$ 2,00 seria R$ 1,50 e não representa o conjunto vendido.

### Exemplo
```SQLite
SELECT status, COUNT(*) AS quantidade
FROM pedidos
GROUP BY status
HAVING COUNT(*) > 20
ORDER BY quantidade DESC, status;
```
Use SUM(peso × preço) / NULLIF(SUM(peso), 0) para calcular uma média ponderada. No SQLite, force uma expressão decimal quando os operandos forem inteiros. NULLIF evita dividir por zero e deixa a falta de base de comparação explícita.
### Prática
1. Conte pedidos por status e reconcilie a soma com 360.
2. Compare WHERE e HAVING mudando uma regra por vez.
3. Teste IS NULL nas datas de recebimento.
4. Calcule preço médio simples e ponderado em um exemplo pequeno.
### Erros frequentes
- Comparar uma coluna com = NULL.
- Misturar coluna não agrupada com agregação sem definir seu significado.
- Tirar a média de percentuais com bases diferentes.
### Referências
SQL básico: Consultar e modificar dados com Transact-SQL — https://learn.microsoft.com/pt-br/training/paths/get-started-querying-with-transact-sql/
SQLite: sintaxe de SELECT — https://www.sqlite.org/lang_select.html

## Semana 6 · SQL: juntar sem duplicar
Uma junção correta combina informações; uma junção mal compreendida multiplica valores. No kit, um pedido pode ter vários itens. Você vai calcular receita, frete e ticket respeitando o detalhe de cada tabela e provar por que os totais continuam corretos depois do JOIN.

### Cardinalidade na prática
A relação pedidos → itens é 1:N. Ao juntar, os atributos do pedido se repetem em cada item. Isso é esperado, mas somar um valor do cabeçalho repetido passa a contar o mesmo valor mais de uma vez. Antes e depois da junção, compare linhas e chaves distintas.

### Cada medida no seu grão
Receita do item é sacos × peso por saco × preço/kg. Frete_total pertence ao pedido. Para somar frete no conjunto de itens, use frete_rateado, já distribuído proporcionalmente ao peso. Ticket usa pedidos distintos, pois a receita de todos os itens pertence aos mesmos pedidos.

### INNER e LEFT JOIN
INNER JOIN mantém apenas combinações encontradas. LEFT JOIN preserva as linhas da esquerda mesmo sem correspondência. Um filtro no WHERE sobre a tabela direita pode eliminar as linhas sem correspondência; pense nessa consequência antes de adicionar o filtro.

### Exemplo
```SQLite
SELECT SUM(i.qtd_sacos*i.peso_saco_kg*i.preco_kg) AS receita,
       SUM(i.frete_rateado) AS frete,
       COUNT(DISTINCT p.id_pedido) AS pedidos
FROM itens_pedido i
JOIN pedidos p ON p.id_pedido=i.id_pedido
WHERE p.status='Faturado';
```
Referência da base de treino: receita R$ 1.236.800,40, frete R$ 37.398,00 e 299 pedidos faturados. O ticket, antes do arredondamento final, é a receita dividida por 299; exibido com duas casas, R$ 4.136,46.
### Prática
1. Conte linhas e pedidos distintos antes e depois do JOIN.
2. Calcule receita e frete com o filtro Faturado.
3. Demonstre, em um pedido com dois itens, como o frete do cabeçalho se repetiria.
4. Compare sua consulta com os resultados do kit.
### Erros frequentes
- Somar frete_total depois de replicá-lo em cada item.
- Usar COUNT(*) da junção como quantidade de pedidos.
- Corrigir um total duplicado com DISTINCT sem investigar a relação.
### Referências
SQL básico: Consultar e modificar dados com Transact-SQL — https://learn.microsoft.com/pt-br/training/paths/get-started-querying-with-transact-sql/
Modelagem: orientação oficial sobre esquema em estrela — https://learn.microsoft.com/pt-br/power-bi/guidance/star-schema

## Semana 7 · SQL: consultas organizadas
Consultas longas ficam mais fáceis de conferir quando cada etapa tem uma responsabilidade. Use CTEs para nomear resultados intermediários, subconsultas para perguntas específicas e testes de ausência para encontrar lacunas. Organização melhora a leitura, mas não garante desempenho por si só.

### Uma etapa com significado
Uma CTE começa com WITH e existe no escopo da instrução. Por exemplo: vendas agrega a receita de cada cliente; resultado filtra os maiores. Defina a granularidade de cada etapa e confira uma amostra antes de adicionar a próxima.

### Encontrar o que não aconteceu
NOT EXISTS é útil para clientes sem pedido faturado. A subconsulta correlacionada compara o ID do cliente externo com os pedidos. Evite assumir que NOT IN terá o mesmo comportamento quando a lista contiver NULL; a ausência precisa ser tratada com cuidado.

### Saldo e recebimento parcial
Em titulos, valor_recebido é a posição acumulada na data-base. Um título de R$ 1.000 com R$ 400 recebidos ainda tem R$ 600 em aberto. A base não tem um histórico de cada parcela, por isso não permite reconstruir um fluxo diário de recebimentos com precisão.

### Exemplo
```SQLite
WITH saldos AS (
  SELECT id_titulo, valor-valor_recebido AS saldo
  FROM titulos
)
SELECT COUNT(*) AS titulos_abertos, SUM(saldo) AS saldo
FROM saldos
WHERE saldo > 0;
```
Separe a transformação (saldo por título) do resumo (quantidade e valor em aberto). Depois valide um título integralmente pago, um parcial e um sem recebimento. A soma de toda a base de treino resulta em saldo a receber de R$ 397.777,06.
### Prática
1. Crie uma CTE que calcule o saldo de cada título.
2. Liste clientes sem pedido Faturado usando NOT EXISTS.
3. Explique em voz alta a entrada e a saída de cada etapa.
4. Documente a limitação do histórico de pagamentos.
### Erros frequentes
- Tratar qualquer recebimento como quitação integral.
- Afirmar que toda CTE cria uma tabela física.
- Prometer que uma CTE torna a consulta mais rápida.
### Referências
SQL: CTEs e organização de consultas — https://learn.microsoft.com/pt-br/sql/t-sql/queries/with-common-table-expression-transact-sql?view=sql-server-ver17
SQLite: sintaxe de SELECT — https://www.sqlite.org/lang_select.html

## Semana 8 · SQL: funções de janela
Funções de janela calculam informações sobre grupos mantendo as linhas do resultado. Você vai criar rankings, comparar períodos e definir desempates. O ponto central é entender a diferença entre resumir um grupo e acrescentar um cálculo a cada linha.

### Agrupamento versus janela
GROUP BY reduz o resultado a uma linha por grupo. Uma função com OVER trabalha sobre uma janela e pode preservar várias linhas. Se o ranking deve ser por pedido, agregue primeiro os itens de cada pedido; ranquear itens não responde à pergunta sobre pedidos.

### Partição, ordem e desempate
PARTITION BY reinicia o cálculo para cada grupo. ORDER BY dentro de OVER define a sequência. ROW_NUMBER atribui números únicos; RANK e DENSE_RANK tratam empates de forma diferente. Acrescente uma chave estável para escolher um único primeiro registro de modo reproduzível.

### Comparar com o anterior
LAG acessa um valor anterior na sequência da janela. Em uma série mensal, confirme se existem todos os meses: a linha anterior disponível pode ser março, mesmo que a linha atual seja maio. Ausência de abril e valor zero em abril são situações diferentes.

### Exemplo
```SQLite
WITH vendas AS (
 SELECT p.id_cliente, p.id_pedido,
        SUM(i.qtd_sacos*i.peso_saco_kg*i.preco_kg) AS receita
 FROM pedidos p JOIN itens_pedido i ON i.id_pedido=p.id_pedido
 WHERE p.status='Faturado'
 GROUP BY p.id_cliente, p.id_pedido
), ranking AS (
 SELECT *, ROW_NUMBER() OVER (
   PARTITION BY id_cliente ORDER BY receita DESC, id_pedido
 ) AS pos FROM vendas
)
SELECT id_cliente,id_pedido,receita FROM ranking
WHERE pos=1 ORDER BY id_cliente;
```
A primeira CTE produz uma linha por pedido. A segunda numera os pedidos de cada cliente do maior para o menor. O ID resolve empates, e a etapa final mantém um pedido por cliente com venda faturada.
### Prática
1. Execute a CTE vendas isoladamente.
2. Compare ROW_NUMBER, RANK e DENSE_RANK em um exemplo com empate.
3. Retorne o maior pedido de cada cliente.
4. Crie um resumo mensal e teste LAG com um mês ausente.
### Erros frequentes
- Ranquear itens quando a pergunta fala em pedidos.
- Omitir o desempate ao escolher uma única linha.
- Interpretar a linha anterior como mês anterior sem conferir o calendário.
### Referências
SQL avançado: ROW_NUMBER e particionamento — https://learn.microsoft.com/pt-br/sql/t-sql/functions/row-number-transact-sql?view=sql-server-ver17
SQLite: sintaxe de SELECT — https://www.sqlite.org/lang_select.html

## Semana 9 · SQL: desempenho e avaliação
Desempenho deve ser investigado com evidência. Uma consulta que pareceu rápida em uma execução pode ter aproveitado cache ou uma amostra pequena. Você vai testar a correção primeiro e comparar planos, leituras e tempos em condições semelhantes no SQL Server.

### O plano conta parte da história
O plano mostra operadores, caminhos de acesso e estimativas. Compare linhas estimadas e observadas e procure junções ou leituras desproporcionais. Um operador visualmente caro é um indício para investigar, não uma prova isolada de que ele está errado.

### Índices têm benefício e custo
Um índice pode ajudar filtros, junções e ordenações, dependendo da consulta e da distribuição dos dados. Ele ocupa espaço e precisa ser mantido quando os dados mudam. Não crie um índice para cada coluna sem medir o efeito sobre a carga de trabalho.

### Comparação controlada
Use o script de desempenho do kit no SSMS. Registre ambiente, consulta, volume, plano e métricas antes e depois. Faça mais de uma execução e explique o efeito do cache. O laboratório SQLite do Atlas não reproduz o otimizador nem as métricas do SQL Server.

### Exemplo
```SQL Server
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
SELECT id_pedido, data_pedido
FROM dbo.pedidos
WHERE data_pedido >= '20260601'
  AND data_pedido < '20260701';
SET STATISTICS IO OFF;
SET STATISTICS TIME OFF;
```
Esse exemplo exige a base criada pelo script do kit no SQL Server. Habilite também o plano de execução no SSMS. O objetivo é descrever a evidência observada; não há um ganho percentual garantido antes do teste.
### Prática
1. Passe nas conferências de receita, frete, pedidos e saldo.
2. Execute o script de desempenho do kit no SQL Server.
3. Compare plano, leituras e tempo em condições registradas.
4. Escreva uma conclusão com o que mudou, o que não mudou e a limitação do teste.
### Erros frequentes
- Escolher a versão mais rápida antes de conferir se devolve o mesmo resultado.
- Usar uma única execução como evidência definitiva.
- Confundir EXPLAIN do SQLite com plano real do SQL Server.
### Referências
SQL: índices e desempenho — https://learn.microsoft.com/pt-br/sql/relational-databases/sql-server-index-design-guide?view=sql-server-ver17

## Semana 10 · Power Query: dados preparados
Power Query transforma a limpeza manual em uma sequência de etapas que pode ser repetida. Você vai importar os CSV, corrigir tipos, mesclar chaves e atualizar a base. A prova de que o processo funciona é substituir a fonte e obter uma saída válida sem refazer tudo à mão.

### Uma transformação por etapa
Nomeie as etapas e confira o resultado de cada uma. Defina os tipos com localidade adequada antes de calcular. Use parâmetros ou uma origem organizada para evitar caminhos escondidos. Não apague o erro sem saber se ele veio de texto inválido, valor ausente ou uma regra incorreta.

### Mesclar e acrescentar
Mesclar combina colunas de tabelas por chaves, como itens com pedidos por id_pedido. Acrescentar empilha linhas de tabelas compatíveis, como arquivos mensais com o mesmo esquema. Antes de expandir uma mesclagem, verifique se a tabela de referência tem uma linha por chave.

### Repetibilidade e qualidade
Faça a limpeza de clientes usando o mesmo balanço de 19 → 16. Depois atualize com uma cópia controlada do arquivo. Confira contagem, chaves distintas e totais. Uma atualização bem-sucedida tecnicamente ainda pode trazer informação errada; a validação faz parte do processo.

### Exemplo
```Power Query M
Table.TransformColumnTypes(
    Fonte,
    {{"preco_kg", type number}, {"peso_saco_kg", type number}},
    "pt-BR"
)
```
Fonte representa a etapa anterior da sua consulta. A localidade pt-BR orienta a interpretação de números com vírgula decimal. Esse trecho é uma transformação M, para Power Query; ele não é uma fórmula de célula nem SQL.
### Prática
1. Importe os CSV e confira separador, codificação e tipos.
2. Trate clientes em uma consulta separada, mantendo quarentena.
3. Mescle itens e pedidos e confira a quantidade de linhas antes e depois.
4. Atualize uma fonte de teste e registre a reconciliação.
### Erros frequentes
- Mesclar por nome em vez de ID.
- Expandir uma tabela com chaves duplicadas e multiplicar os itens.
- Trocar erros por zero sem investigar.
### Referências
Power BI: preparar, limpar e visualizar dados — https://learn.microsoft.com/pt-br/training/paths/prepare-visualize-data-power-bi/

## Semana 11 · Modelo de dados confiável
O modelo organiza o caminho que os filtros percorrem. Um bom modelo permite explicar por que selecionar um cliente muda receita, quantidade e margem. Nesta semana você vai separar fatos e dimensões e testar as relações com exemplos pequenos antes de montar os visuais.

### Fatos e dimensões
Fatos guardam eventos e medidas no detalhe escolhido. Dimensões descrevem entidades como cliente e produto. FatoVendas terá uma linha por item faturado; DimClientes terá uma linha por cliente. Não misture linhas de total mensal e linhas de item na mesma medida sem uma regra explícita.

### Relações 1:N
A chave da dimensão deve ser única e os tipos precisam ser compatíveis com a chave do fato. Como ponto de partida, use filtro da dimensão para o fato. Relações bidirecionais e muitos-para-muitos exigem justificativa; não corrigem automaticamente uma dimensão duplicada.

### Mais de um processo
Vendas, recebíveis e estoque têm grãos diferentes. Trate-os como fatos separados, compartilhando dimensões quando fizer sentido. Uma junção direta entre itens e títulos pode repetir títulos por item e multiplicar saldos. Documente as relações e teste cada indicador isoladamente.

### Exemplo
```Esquema
DimClientes (1) → (N) FatoVendas
DimProdutos (1) → (N) FatoVendas
Calendario  (1) → (N) FatoVendas

FatoVendas: uma linha por item de pedido Faturado.
```
Ao filtrar um produto, some apenas os itens correspondentes. Ao filtrar um cliente, a dimensão deve alcançar o fato pela chave. Se o total muda inesperadamente, confira chaves, valores sem correspondência e direção do filtro antes de modificar a medida.
### Prática
1. Monte FatoVendas a partir de itens e pedidos filtrados.
2. Crie as dimensões com chaves distintas.
3. Documente o grão e a direção de cada relação.
4. Teste filtros de um cliente e de um produto e concilie com SQL.
### Erros frequentes
- Criar N:N para esconder duplicatas.
- Relacionar tabelas fato diretamente para tentar fazer todos os filtros funcionarem.
- Validar só o total geral, sem cortes por cliente e produto.
### Referências
Modelagem: orientação oficial sobre esquema em estrela — https://learn.microsoft.com/pt-br/power-bi/guidance/star-schema

## Semana 12 · Datas e visualização
Uma série de datas precisa ter ordem e cobertura. Você vai criar um calendário consistente e escolher visuais que respondam à pergunta do usuário. A clareza vem de títulos, unidades, filtros e comparações que possam ser explicados.

### Calendário contínuo
Crie uma linha por dia, sem duplicatas, cobrindo as datas necessárias às análises. Para estoque, inclua 31/12/2025, data do saldo inicial do treino. Uma tabela que começa em janeiro pode perder a posição anterior e mudar o saldo.

### Ordem e comparação
Use ano e mês para evitar juntar janeiros de anos diferentes. Ordene o nome do mês pelo número correspondente e prefira uma chave ano-mês em séries longas. Uma linha mostra evolução; barras comparam categorias. Evite uma pizza com muitas categorias quando a comparação é o objetivo.

### Visual que informa
Informe moeda, kg, período e população considerada. Não use apenas cor para distinguir estados. Teste contraste, legibilidade e filtros. Um cartão de faturamento deve deixar claro se mostra pedidos Faturados e qual intervalo de datas está selecionado.

### Exemplo
```DAX
Calendario = CALENDAR(DATE(2025,12,31), DATE(2027,3,31))
Ano = YEAR(Calendario[Date])
MesNumero = MONTH(Calendario[Date])
AnoMes = FORMAT(Calendario[Date], "yyyy-MM")
```
Crie as três colunas depois de criar a tabela. Renomeie Date para Data se seguir as medidas do kit e atualize as referências. Marque a tabela de datas e relacione-a com a data do processo correto; data de pedido e data de vencimento respondem a perguntas diferentes.
### Prática
1. Crie e valide o calendário sem datas repetidas.
2. Teste a ordem dos meses em um gráfico.
3. Monte uma página com receita, peso e pedidos com unidades claras.
4. Selecione um mês e compare os cartões com uma consulta SQL equivalente.
### Erros frequentes
- Ordenar mês por receita quando a intenção é mostrar tempo.
- Excluir o saldo inicial ao filtrar estoque.
- Apresentar um número sem unidade ou período.
### Referências
Power BI: preparar, limpar e visualizar dados — https://learn.microsoft.com/pt-br/training/paths/prepare-visualize-data-power-bi/
Modelagem: orientação oficial sobre esquema em estrela — https://learn.microsoft.com/pt-br/power-bi/guidance/star-schema

## Semana 13 · DAX: medidas essenciais
Medidas DAX respondem ao contexto da análise. Você vai construir o conjunto básico do painel e conferir cada valor com SQL. Comece por receita, custo, frete e quantidade de pedidos; derive margem e ticket a partir dessas medidas já conferidas.

### SUM e SUMX
SUM soma uma coluna. SUMX percorre uma tabela e avalia uma expressão por linha antes de somar. Se a receita depende de sacos × peso × preço, SUMX permite escrever essa expressão. Uma coluna calculada também pode materializar receita, mas tem papel e custo diferentes no modelo.

### Razões entre totais
Margem percentual é resultado total dividido por receita total. Ticket é receita total dividida por pedidos distintos. Use DIVIDE para tratar denominador zero. Formate margem como percentual: uma fração 0,1912 será exibida como 19,12%, sem multiplicar a medida por 100 novamente.

### Premissas da FatoVendas
As medidas abaixo pressupõem FatoVendas contendo somente itens de pedidos Faturados e o frete_rateado. Se sua tabela tiver todos os status, aplique o filtro explicitamente ou ajuste a preparação. Uma fórmula correta sobre uma tabela com regra diferente produz outro indicador.

### Exemplo
```DAX
Faturamento = SUMX(FatoVendas, FatoVendas[qtd_sacos] * FatoVendas[peso_saco_kg] * FatoVendas[preco_kg])
Pedidos faturados = DISTINCTCOUNT(FatoVendas[id_pedido])
Ticket medio = DIVIDE([Faturamento], [Pedidos faturados])
Margem percentual = DIVIDE([Resultado comercial], [Faturamento])
```
Antes da margem, crie Custo produtos e Frete conforme o kit e depois Resultado comercial = [Faturamento] - [Custo produtos] - [Frete]. Na base de treino: resultado R$ 236.516,00 e margem de 19,12%, com arredondamento de exibição.
### Prática
1. Crie uma medida por indicador, usando nomes claros.
2. Concilie cada medida com SQL no total.
3. Repita a conferência em um produto e um cliente.
4. Valide um contexto sem vendas e registre o comportamento esperado.
### Erros frequentes
- Somar preços por kg para obter receita.
- Multiplicar por 100 e também formatar como percentual.
- Usar a média das margens de cada item como margem total.
### Referências
Power BI: modelagem e DAX — https://learn.microsoft.com/pt-br/training/paths/model-data-power-bi/
DAX: função DIVIDE — https://learn.microsoft.com/pt-br/dax/divide-function-dax

## Semana 14 · DAX: contexto de filtro
O mesmo cálculo pode devolver valores diferentes em cartões, linhas e segmentações porque cada visual aplica filtros. Você vai tornar esse comportamento explícito e usar CALCULATE para modificar o contexto com intenção.

### Contexto de filtro
O contexto vem de segmentações, linhas e colunas do visual e relações do modelo. Uma medida de faturamento não carrega um único número fixo: ela é avaliada no conjunto visível em cada célula. Teste primeiro filtros de uma dimensão por vez.

### CALCULATE e denominadores
CALCULATE avalia uma expressão em contexto de filtro modificado. Para participação do produto, o numerador mantém o produto atual e o denominador pode remover apenas o filtro de produto. Remover filtros demais muda a pergunta e pode ignorar o período selecionado.

### Total que não é soma de percentuais
O total de uma medida é recalculado no contexto total. Para margem, isso é desejável: resultado total / receita total. Somar ou tirar a média das margens exibidas nas linhas não preserva necessariamente a ponderação.

### Exemplo
```DAX
Receita todos produtos =
CALCULATE([Faturamento], REMOVEFILTERS(DimProdutos))

Participacao produto =
DIVIDE([Faturamento], [Receita todos produtos])
```
As medidas pressupõem uma DimProdutos relacionada ao fato. O denominador remove filtros dessa dimensão e preserva outros contextos, como cliente e data. Se você filtrar diretamente uma coluna de produto no fato, investigue esse filtro separadamente.
### Prática
1. Monte uma matriz de faturamento por produto.
2. Crie participação removendo apenas o filtro necessário.
3. Aplique filtro de cliente e mês e explique o denominador.
4. Reproduza o resultado de um produto em SQL.
### Erros frequentes
- Remover todos os filtros sem perceber que o período também mudou.
- Corrigir a medida antes de conferir os relacionamentos.
- Somar percentuais das linhas para calcular uma margem.
### Referências
Power BI: modelagem e DAX — https://learn.microsoft.com/pt-br/training/paths/model-data-power-bi/
DAX: função CALCULATE — https://learn.microsoft.com/pt-br/dax/calculate-function-dax

## Semana 15 · DAX: tempo e segunda avaliação
Comparar meses exige uma base de datas coerente e uma regra clara para ausência de histórico. Você vai calcular mês anterior, variação e acumulado e conferir cada mês com o resumo SQL da base de treino.

### Base de comparação
Variação = (valor atual − valor anterior) / valor anterior. Quando não há valor anterior, crescimento zero não descreve a situação. Use uma ausência explicada, e trate denominador zero conforme a regra do indicador.

### Tempo no modelo
As funções de tempo precisam de um calendário apropriado e de relação ativa com a data correta. Uma segmentação da data de vencimento não substitui automaticamente o contexto da data de venda. Confira o modelo antes de atribuir a diferença à fórmula.

### Acumulado com limites
Defina o começo do intervalo e a data final. Um acumulado anual de março normalmente soma janeiro, fevereiro e março daquele ano. Compare com uma consulta com limites explícitos e confira o que acontece ao selecionar outro ano ou apenas um mês.

### Exemplo
```DAX
Receita mes anterior =
CALCULATE([Faturamento], DATEADD(Calendario[Data], -1, MONTH))

Variacao mensal =
IF(ISBLANK([Receita mes anterior]), BLANK(),
   DIVIDE([Faturamento]-[Receita mes anterior], [Receita mes anterior]))
```
No treino, janeiro tem R$ 188.623,05 e fevereiro R$ 166.787,20. A variação de fevereiro é aproximadamente −11,58%. Confira a conta sem arredondar os valores intermediários. Janeiro não tem mês anterior na base de vendas fornecida.
### Prática
1. Concilie os seis meses do treino com SQL.
2. Calcule mês anterior e variação.
3. Teste primeiro mês, mês sem vendas e denominador zero.
4. Construa um acumulado e explique seu intervalo.
### Erros frequentes
- Interpretar falta de histórico como variação de 0%.
- Comparar meses de anos diferentes por nome.
- Arredondar valores intermediários e acumular diferença.
### Referências
Power BI: modelagem e DAX — https://learn.microsoft.com/pt-br/training/paths/model-data-power-bi/

## Semana 16 · Atualização e sustentação
Um relatório útil precisa continuar funcionando depois da entrega. Você vai documentar a atualização, simular falhas e distinguir o que pode testar localmente do que depende de conta, permissão e licença no Power BI Service.

### Atualizar e conferir
Atualizar é buscar a fonte e reprocessar as transformações e o modelo. Registre quando a execução ocorreu e valide se as novas linhas e valores chegaram. Clicar em Atualizar sem conferir a saída não prova que o relatório está correto.

### Acesso e ambiente
Power BI Desktop permite desenvolver o relatório localmente. O Service envolve autenticação e regras de licença, capacidade e permissão. Compartilhamento e colaboração dependem da configuração. Se não houver acesso, execute a atividade local e identifique explicitamente os testes de nuvem pendentes.

### Incidente com evidência
Um chamado deve registrar sintoma, impacto, hipótese, causa, correção e resultado conferido. Simule CSV ausente, chave duplicada e preço importado com tipo incorreto. Um gateway é relevante para acesso a determinadas fontes locais; ele não corrige uma transformação errada.

### Exemplo
```Registro de incidente
Sintoma: atualização falha ao expandir cadastro.
Causa confirmada: id_cliente repetido na dimensão.
Correção: tratar a duplicata na origem/consulta.
Validação: chave única, linhas e receita conciliadas.
Pendente: testar agendamento no Service com conta autorizada.
```
A documentação de aprendizado pode ser lida sem perfil no Microsoft Learn. Isso não concede automaticamente uma licença para recursos do Service. Evite Publicar na Web com dados reais: esse recurso cria acesso público; para portfólio, use dados fictícios ou uma versão autorizada e anonimizada.
### Prática
1. Atualize o relatório local e confira o resultado.
2. Simule e registre três incidentes com correções.
3. Liste conta, permissões e requisitos de publicação do seu ambiente.
4. Marque como pendente qualquer teste de nuvem que você não executou.
### Erros frequentes
- Afirmar que testou compartilhamento sem ter acesso ao Service.
- Usar Publicar na Web como se fosse acesso privado.
- Alterar a relação para N:N apenas para a atualização passar.
### Referências
Power BI Desktop: download e instalação — https://learn.microsoft.com/pt-br/power-bi/fundamentals/desktop-get-the-desktop
Power BI Service: recursos conforme licença — https://learn.microsoft.com/pt-br/power-bi/fundamentals/service-features-license-type
Power BI Service: gerenciar e proteger — https://learn.microsoft.com/pt-br/training/paths/manage-secure-power-bi/
Microsoft Learn: custo e necessidade de perfil — https://learn.microsoft.com/pt-br/training/support/faq
Power BI: o que significa Publicar na Web — https://learn.microsoft.com/pt-br/power-bi/collaborate-share/service-publish-to-web

## Semana 17 · Projeto 1: vendas e resultado
Seu primeiro projeto vai responder quanto foi vendido, o que mais contribuiu para o resultado e onde investigar. O objetivo é entregar uma análise conciliada que outra pessoa consiga atualizar e interpretar, usando as regras didáticas da distribuidora.

### Briefing da página
Defina o usuário e a decisão. Exemplo: acompanhar vendas por produto e priorizar investigação de margens baixas. Escolha poucos indicadores de abertura: receita, resultado, margem, peso e pedidos. Cada um precisa de unidade, período e regra documentada.

### Receita não é resultado
Resultado comercial do kit = receita − custo dos produtos − frete. Impostos, perdas e despesas administrativas não estão modelados. Por isso, apresente o indicador como resultado comercial simplificado, sem chamá-lo de lucro contábil final.

### Entrega demonstrável
Organize página de visão geral, detalhe e uma seção de regras. Salve consultas de conciliação, explique três achados e registre duas limitações. Uma recomendação deve separar o que o dado mostra da hipótese que ainda precisa ser investigada.

### Exemplo
```Reconciliação
Receita:          R$ 1.236.800,40
Custo produtos:   R$   962.886,40
Frete:            R$    37.398,00
Resultado:        R$   236.516,00
Margem exibida:    19,12%
```
Os números são referências da base fictícia de treino. Use valores não arredondados nas medidas e arredonde apenas a exibição. Não apresente esses valores como resultados reais da sua empresa.
### Prática
1. Defina a decisão e o público do relatório.
2. Concilie receita, custo, frete, peso, pedidos e ticket.
3. Crie duas páginas e teste filtros de produto e período.
4. Escreva um README com regras, atualização, evidências e limitações.
### Erros frequentes
- Chamar receita de lucro.
- Atribuir um ganho ao painel sem medição.
- Usar dados reais identificáveis no portfólio público.
### Referências
Modelagem: orientação oficial sobre esquema em estrela — https://learn.microsoft.com/pt-br/power-bi/guidance/star-schema
Power BI: o que significa Publicar na Web — https://learn.microsoft.com/pt-br/power-bi/collaborate-share/service-publish-to-web

## Semana 18 · Projeto 2: estoque
Estoque é uma posição acumulada, enquanto entradas e saídas são movimentos. Você vai construir os dois indicadores sem perder o saldo inicial e mostrar por que um filtro mensal pode mudar a pergunta respondida pelo visual.

### Movimentos com sinal
Na base, peso_kg é positivo. O campo tipo determina o sinal: Entrada soma e Saida subtrai. Primeiro teste uma conta pequena: saldo inicial 2.000, entrada 500, saída 1.200 → saldo 1.300 kg. Depois use a mesma regra na base completa.

### Posição na data
Saldo em 30/06 inclui o movimento inicial e todos os movimentos até a data. Somar somente junho calcula o movimento líquido de junho, não necessariamente a posição no fim do mês. Escreva a diferença no título e na documentação do indicador.

### Conferência por produto
Valide o saldo de cada produto com SQL e confirme as bordas de data. Saldo negativo pode ser um problema ou uma condição possível do processo; investigue antes de forçar zero. A base não contém reservas nem pedidos futuros, então não representa disponibilidade prometida.

### Exemplo
```SQLite
SELECT id_produto,
 SUM(CASE WHEN tipo='Entrada' THEN peso_kg ELSE -peso_kg END) AS saldo_kg
FROM movimentos_estoque
WHERE data_movimento <= '2026-06-30'
GROUP BY id_produto
ORDER BY id_produto;
```
Saldos esperados em kg: milho 244.675; quirera 240.850; farelo de trigo 161.120; farelo de soja 129.850. A consulta pressupõe os tipos Entrada e Saida do kit; em uma base real, valide valores inesperados antes do ELSE.
### Prática
1. Concilie todos os movimentos com sinal.
2. Inclua o saldo inicial e calcule posição até a data-base.
3. Mostre separadamente entrada, saída e saldo.
4. Teste um mês isolado e explique a diferença entre fluxo e posição.
### Erros frequentes
- Filtrar somente as datas das vendas para calcular estoque.
- Esquecer o movimento inicial de dezembro.
- Interpretar estoque físico como estoque disponível sem dados de reservas.
### Referências
Modelagem: orientação oficial sobre esquema em estrela — https://learn.microsoft.com/pt-br/power-bi/guidance/star-schema
SQLite: sintaxe de SELECT — https://www.sqlite.org/lang_select.html

## Semana 19 · Projeto 3: recebíveis
O relatório de recebíveis precisa distinguir valor original, valor recebido, saldo aberto e saldo vencido. Você vai usar uma data-base fixa e tratar corretamente pagamentos parciais, vencimentos e faixas de atraso.

### Regra do saldo
Saldo = valor − valor_recebido. Para analisar pendências, mantenha saldo positivo. Um recebimento parcial reduz a dívida sem encerrá-la. Confira registros individuais antes de agregar, incluindo título pago, parcial e sem recebimento.

### Regra do vencido
No kit, vencido tem vencimento anterior à data-base. Um título que vence no próprio dia ainda não entra nessa categoria. Use 30/06/2026 no treino e 31/12/2026 na avaliação. Usar a data atual do computador muda o conjunto e impede reproduzir o gabarito.

### Faixas e limitações
Depois de filtrar os títulos vencidos, classifique em 1–30, 31–60, 61–90 e acima de 90 dias. Não misture títulos a vencer com atraso zero sem identificar a categoria. A base registra posição acumulada, por isso não prova em quais dias cada parcela foi paga.

### Exemplo
```SQLite
SELECT ROUND(SUM(valor-valor_recebido),2) AS saldo_vencido
FROM titulos
WHERE valor-valor_recebido > 0
  AND data_vencimento < '2026-06-30';
```
Referências de treino: saldo em aberto R$ 397.777,06; saldo vencido R$ 248.402,91. A diferença entre eles não é um erro: parte do saldo ainda não venceu pela convenção da data-base.
### Prática
1. Calcule aberto e vencido com a data-base fixa.
2. Confira um título com recebimento parcial.
3. Crie faixas de atraso sem sobreposição.
4. Documente o que a base permite e o que falta para analisar fluxo de caixa.
### Erros frequentes
- Contar o valor original inteiro após pagamento parcial.
- Usar HOJE/TODAY para conciliar uma posição histórica.
- Aplicar <= quando a regra usa vencimento estritamente anterior.
### Referências
Power BI: modelagem e DAX — https://learn.microsoft.com/pt-br/training/paths/model-data-power-bi/
SQLite: sintaxe de SELECT — https://www.sqlite.org/lang_select.html

## Semana 20 · Projeto aplicado ao seu negócio
Agora use o que aprendeu para uma pergunta real do seu negócio. Comece pequeno: uma decisão, um usuário e fontes disponíveis. Dados reais exigem cuidado com autorização, identificação de clientes e valores comerciais; mantenha uma versão fictícia ou anonimizada para demonstração externa.

### Da dúvida à decisão
Troque “quero um dashboard” por uma pergunta concreta, como “quais produtos combinam maior peso vendido e menor resultado por kg?”. Defina quem usará a resposta, com que frequência e que ação pode tomar. Se a decisão depende de um custo ausente, registre a lacuna.

### Contrato dos dados
Liste fonte, responsável, periodicidade, período, chaves, unidades e significado dos status. Confira se preço é por kg, saco ou tonelada. Compare 40 sacos de 25 kg com 1 tonelada só depois de converter ambos para 1.000 kg.

### Escopo que pode ser validado
Escolha três indicadores e uma rotina de atualização. Produza uma primeira versão e valide os números com quem conhece o processo. Uma boa documentação mostra também o que ficou fora: custos não recebidos, datas não confiáveis ou campos ainda sem padrão.

### Exemplo
```Briefing
Usuário: responsável por vendas.
Decisão: investigar produtos com menor resultado por kg.
Recorte: pedidos faturados do período acordado.
Fonte: exportação autorizada e conferida.
Indicadores: receita, peso, resultado comercial.
Limite: custos e despesas ausentes explicitados.
```
Use o exemplo como estrutura e preencha com fatos do seu projeto. Não há necessidade de anexar nomes, documentos ou dados bancários de clientes ao portfólio. Uma amostra fictícia permite demonstrar as regras sem expor o negócio.
### Prática
1. Registre a pergunta e a pessoa que validará a entrega.
2. Mapeie fonte, chaves, unidades e limites.
3. Crie três indicadores e confira amostras com a operação.
4. Prepare uma cópia de demonstração sem dados identificáveis.
### Erros frequentes
- Definir a conclusão antes de analisar.
- Misturar tonelada e kg.
- Publicar informações de clientes para provar experiência.
### Referências
Modelagem: orientação oficial sobre esquema em estrela — https://learn.microsoft.com/pt-br/power-bi/guidance/star-schema
Power BI: o que significa Publicar na Web — https://learn.microsoft.com/pt-br/power-bi/collaborate-share/service-publish-to-web

## Semana 21 · Entrega e uso real
A entrega termina quando o usuário consegue interpretar e atualizar o trabalho. Nesta semana você vai testar com outra pessoa, registrar feedback e separar utilidade percebida de resultado medido. Uma demonstração clara é parte da competência técnica.

### Validação com o usuário
Peça que a pessoa execute uma tarefa: escolher um período, encontrar um produto e explicar um indicador. Observe onde ela hesita. Registre data, tarefa, feedback e alteração feita. Confirme também os números contra a fonte, não apenas a aparência.

### Uso e efeito não são a mesma coisa
Registrar que alguém usou o painel demonstra adoção. Afirmar que o painel aumentou vendas exige medir e considerar outros fatores. Mudanças de preço, sazonalidade, clientes e oferta podem explicar o resultado. Evite transformar coincidência temporal em causa.

### Handoff reproduzível
Entregue README, regras, consultas de conferência e procedimento de atualização. Identifique quem opera e o que fazer se a fonte mudar. Uma captura de tela mostra o visual, mas o conjunto de arquivos e explicações permite avaliar como o trabalho foi produzido.

### Exemplo
```Registro de feedback
Tarefa testada: localizar receita de milho em junho.
Resultado observado: usuário completou com orientação.
Problema: filtro de período pouco visível.
Ajuste: mover filtro e indicar período no título.
Reteste: registrar o que ocorreu após a alteração.
```
O exemplo descreve um protocolo, não um feedback que já aconteceu. No seu projeto, preencha apenas observações reais. Se ainda não houve validação externa, mantenha esse item pendente e use uma simulação claramente identificada.
### Prática
1. Demonstre o projeto em até cinco minutos.
2. Registre ao menos uma tarefa e feedback real, se disponível.
3. Faça um ajuste justificável e reteste.
4. Entregue documentação, atualização e limitações.
### Erros frequentes
- Inventar depoimento ou ganho para fortalecer o portfólio.
- Aceitar uma aprovação visual como validação dos dados.
- Deixar a atualização dependente de passos não documentados.
### Referências
Power BI: o que significa Publicar na Web — https://learn.microsoft.com/pt-br/power-bi/collaborate-share/service-publish-to-web

## Semana 22 · Portfólio e candidaturas
Seu portfólio deve tornar as competências fáceis de verificar. Você já pode conectar projetos de site, automação de faturamento e análise de dados, desde que descreva seu papel e o estágio de cada um com precisão. O foco continua em oportunidades 100% remotas compatíveis com o que você consegue demonstrar.

### Uma história verificável
Apresente problema, dados, decisões técnicas, resultado observado e limitações. Separe um protótipo de uma solução em uso. Mostre trechos de consulta, regras de negócio e testes que você consegue explicar. Não substitua experiência real por um cargo inventado.

### Repositório e apresentação
Um README pode conter objetivo, instruções, estrutura, indicadores e imagens com dados fictícios. No Git, commits registram versões; faça mensagens que expliquem o que mudou. Nunca inclua credenciais nem arquivos de clientes em um repositório de demonstração.

### Candidatura com aderência
Leia modalidade, atividades e requisitos. Compare cada exigência com uma evidência sua e registre lacunas de estudo. Auxílio home office não comprova atuação totalmente remota. Em entrevistas, diferencie inglês de leitura de capacidade de conversação.

### Exemplo
```README
# Projeto de análise de vendas
## Problema e decisão
## Fontes fictícias e regras
## Ferramentas e minha contribuição
## Indicadores conciliados
## Como reproduzir
## Limitações e próximos passos
```
Use resultados observados no seu projeto. Se a base for didática, diga isso. Você pode citar o aplicativo de faturamento, o site e o Atlas como projetos próprios, explicando o que implementou, testou e ainda precisa desenvolver.
### Prática
1. Escreva um README completo para um projeto.
2. Prepare uma apresentação de dois minutos.
3. Monte uma tabela requisito → evidência → lacuna para uma vaga.
4. Revise dados e arquivos antes de compartilhar o portfólio.
### Erros frequentes
- Declarar anos de experiência que não possui.
- Prometer domínio de uma ferramenta que só acompanhou em vídeo.
- Confundir vaga híbrida com remota.
### Referências
Pro Git em português — https://git-scm.com/book/pt-br/v2

## Semana 23 · Simulação técnica e revisão
A simulação técnica mede o que você consegue fazer sem seguir cada passo de uma aula. Você vai trabalhar com tempo delimitado, explicar raciocínios e revisar erros com uma variação dos dados. Use o simulado conceitual do Atlas como diagnóstico e o kit como prática técnica.

### Antes de executar
Leia o enunciado, defina população, datas, unidade e resultado esperado. Faça uma pequena conta manual para conferir a direção da resposta. Planeje consultas intermediárias em vez de construir tudo de uma vez.

### Responder e explicar
Uma resposta técnica deve explicar regra, implementação e validação. Se o número não bate, confira chaves, tipos, filtros e granularidade. Registre a hipótese e o teste realizado. Admitir uma limitação com precisão é melhor que dar certeza sem evidência.

### Revisar para transferir
Depois da tentativa, compare com a referência, classifique a causa do erro e refaça uma versão diferente. Troque produto, período ou unidade. O objetivo é transferir a regra, e não memorizar a posição da alternativa correta.

### Exemplo
```Roteiro de solução
1. Definir pergunta, recorte e unidade.
2. Conferir chaves e tipos.
3. Calcular uma etapa por vez.
4. Reconciliar total e cortes.
5. Explicar resultado e limitações.
6. Refazer uma variação do que errou.
```
Os simulados do Atlas corrigem questões conceituais e numéricas do banco. Eles não avaliam sozinhos a capacidade de construir um relatório Power BI ou investigar um incidente real. A avaliação final mantém a rubrica e os controles críticos do plano.
### Prática
1. Faça um simulado sem consultar o gabarito.
2. Registre as duas competências com mais dificuldade.
3. Refaça consultas e cálculos relacionados aos erros.
4. Explique uma solução em voz alta e guarde a evidência.
### Erros frequentes
- Abrir a explicação antes da primeira tentativa.
- Memorizar respostas sem compreender a regra.
- Tratar nota de simulado como garantia de contratação.
### Referências
SQL básico: Consultar e modificar dados com Transact-SQL — https://learn.microsoft.com/pt-br/training/paths/get-started-querying-with-transact-sql/
Power BI: modelagem e DAX — https://learn.microsoft.com/pt-br/training/paths/model-data-power-bi/

## Semana 24 · Avaliação final com dados novos
A avaliação final reúne consultas, relatório, qualidade e comunicação. Use a base de avaliação, com posição em 31/12/2026, e produza as evidências antes de preencher a rubrica. Concluir o plano mostra o trabalho realizado e aponta o que ainda merece reforço.

### Uma base diferente
O kit contém uma base final separada da base de treino. Não use os totais memorizados do semestre anterior. Aplique as mesmas regras a novos dados, confira a nova data-base e explique eventuais diferenças.

### Rubrica com evidência
O plano usa 100 pontos: SQL 30, Power BI 30, Excel 10, qualidade 15 e comunicação 15. A meta é 80, com pelo menos 24 em SQL e 24 em Power BI. O preenchimento é uma autoavaliação guiada; os projetos e as consultas sustentam a nota.

### Controles obrigatórios
Receita, chaves, filtro de status, frete, ticket e datas precisam passar. Um total monetário aceita a tolerância documentada de R$ 0,01. Se um controle falhar, corrija antes de considerar os critérios atendidos, mesmo com uma nota total alta.

### Exemplo
```Checklist de evidências
SQL: consultas salvas e resultados conferidos.
Power BI: modelo, medidas, filtros e atualização.
Excel: importação, fórmulas e resumo.
Qualidade: chaves, unidades, datas e conciliação.
Comunicação: problema, decisão, limites e reprodução.
```
Uma soma de 84 pontos, com SQL 26 e Power BI 25, atinge os mínimos numéricos, mas ainda depende de todos os controles críticos. A conclusão demonstra competências treinadas, sem equivaler a certificação oficial ou contratação garantida.
### Prática
1. Troque o laboratório para a base de avaliação final.
2. Resolva as tarefas sem abrir o gabarito na primeira tentativa.
3. Registre a pontuação com evidências e confira os controles.
4. Faça um plano de reforço para as lacunas encontradas.
### Erros frequentes
- Usar a data-base de junho na avaliação de dezembro.
- Aprovar um resultado com frete duplicado porque a nota ficou alta.
- Apresentar o plano como uma certificação oficial.
### Referências
SQL básico: Consultar e modificar dados com Transact-SQL — https://learn.microsoft.com/pt-br/training/paths/get-started-querying-with-transact-sql/
Power BI: modelagem e DAX — https://learn.microsoft.com/pt-br/training/paths/model-data-power-bi/
