-- Semana 9: execute conectado ao banco EstudoBI_Lucas.
-- Cria apenas uma tabela TEMPORÁRIA na sessão. Não altera as tabelas de treino.
;WITH d(n) AS (SELECT n FROM (VALUES(0),(1),(2),(3),(4),(5),(6),(7),(8),(9)) x(n)),
nums AS (SELECT a.n+10*b.n+100*c.n AS n FROM d a CROSS JOIN d b CROSS JOIN d c)
SELECT TOP (200000) ROW_NUMBER() OVER(ORDER BY i.id_item,n.n) AS id_volume,
 p.data_pedido,p.id_cliente,i.id_produto,i.qtd_sacos*i.peso_saco_kg*i.preco_kg AS receita
INTO #FatoVolume FROM estudo.itens_pedido i JOIN estudo.pedidos p ON p.id_pedido=i.id_pedido CROSS JOIN nums n
WHERE p.status=N'Faturado';
SET STATISTICS IO ON;
SET STATISTICS TIME ON;
-- Ative o plano de execução real no SSMS. Compare leituras e plano, além do tempo.
SELECT SUM(receita) FROM #FatoVolume WHERE data_pedido>='2026-06-01' AND data_pedido<'2026-07-01';
CREATE INDEX IX_FatoVolume_Data ON #FatoVolume(data_pedido) INCLUDE(receita);
SELECT SUM(receita) FROM #FatoVolume WHERE data_pedido>='2026-06-01' AND data_pedido<'2026-07-01';
-- Discuta seletividade, cache, custo de escrita e por que o otimizador pode escolher Scan.
-- A tabela temporária desaparece quando a sessão for fechada.
