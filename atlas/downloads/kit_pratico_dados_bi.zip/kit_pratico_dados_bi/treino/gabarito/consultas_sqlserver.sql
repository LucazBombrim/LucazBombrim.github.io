-- Execute no banco de treino ou avaliação. Data-base: mude só a variável abaixo.
DECLARE @DataBase date = '2026-06-30';
-- 01: pedidos por status
SELECT status, COUNT(*) AS pedidos FROM estudo.pedidos GROUP BY status;
-- 02-03: métricas sem duplicar frete ou contar itens como pedidos
SELECT COUNT(DISTINCT p.id_pedido) AS pedidos_faturados,
 SUM(i.qtd_sacos*i.peso_saco_kg*i.preco_kg) AS faturamento,
 SUM(i.qtd_sacos*i.peso_saco_kg*i.custo_kg) AS custo_produtos,
 SUM(i.frete_rateado) AS frete,
 SUM(i.qtd_sacos*i.peso_saco_kg*(i.preco_kg-i.custo_kg)-i.frete_rateado) AS resultado_comercial,
 SUM(i.qtd_sacos*i.peso_saco_kg) AS peso_kg,
 SUM(i.qtd_sacos*i.peso_saco_kg*i.preco_kg)/NULLIF(COUNT(DISTINCT p.id_pedido),0) AS ticket_medio
FROM estudo.itens_pedido i JOIN estudo.pedidos p ON p.id_pedido=i.id_pedido
WHERE p.status=N'Faturado';
-- 04: produto; para cliente troque o agrupamento para p.id_cliente
SELECT pr.produto, SUM(i.qtd_sacos*i.peso_saco_kg*i.preco_kg) AS receita
FROM estudo.itens_pedido i JOIN estudo.pedidos p ON p.id_pedido=i.id_pedido
JOIN estudo.produtos pr ON pr.id_produto=i.id_produto
WHERE p.status=N'Faturado' GROUP BY pr.produto ORDER BY receita DESC;
SELECT TOP (5) p.id_cliente, SUM(i.qtd_sacos*i.peso_saco_kg*i.preco_kg) AS receita
FROM estudo.itens_pedido i JOIN estudo.pedidos p ON p.id_pedido=i.id_pedido
WHERE p.status=N'Faturado' GROUP BY p.id_cliente ORDER BY receita DESC,p.id_cliente;
-- 05: receita mensal e comparação; janeiro fica NULL por falta de mês anterior
;WITH mensal AS (
 SELECT CONVERT(char(7),p.data_pedido,120) AS mes,
 SUM(i.qtd_sacos*i.peso_saco_kg*i.preco_kg) AS receita
 FROM estudo.itens_pedido i JOIN estudo.pedidos p ON p.id_pedido=i.id_pedido
 WHERE p.status=N'Faturado' GROUP BY CONVERT(char(7),p.data_pedido,120)
), comparacao AS (SELECT mes,receita,LAG(receita) OVER(ORDER BY mes) AS receita_anterior FROM mensal)
SELECT mes,receita,receita_anterior,
 100.0*(receita-receita_anterior)/NULLIF(receita_anterior,0) AS variacao_percentual
FROM comparacao ORDER BY mes;
-- 06: maior pedido de cada cliente com desempate explícito
;WITH valores AS (
 SELECT p.id_cliente,p.id_pedido,SUM(i.qtd_sacos*i.peso_saco_kg*i.preco_kg) AS receita
 FROM estudo.pedidos p JOIN estudo.itens_pedido i ON i.id_pedido=p.id_pedido
 WHERE p.status=N'Faturado' GROUP BY p.id_cliente,p.id_pedido
), ranking AS (SELECT *, ROW_NUMBER() OVER(PARTITION BY id_cliente ORDER BY receita DESC,id_pedido) AS posicao FROM valores)
SELECT id_cliente,id_pedido,receita FROM ranking WHERE posicao=1 ORDER BY id_cliente;
-- 07: ausência; zero linhas também é uma resposta possível nesta base
SELECT c.* FROM estudo.clientes c WHERE NOT EXISTS(
 SELECT 1 FROM estudo.pedidos p WHERE p.id_cliente=c.id_cliente AND p.status=N'Faturado');
-- 08: chaves de pedidos; adapte para produtos, clientes e títulos
SELECT i.id_item FROM estudo.itens_pedido i LEFT JOIN estudo.pedidos p ON p.id_pedido=i.id_pedido WHERE p.id_pedido IS NULL;
-- 09: valores em aberto e vencidos na data-base; não usar a data atual
SELECT SUM(valor-valor_recebido) AS saldo_a_receber,
 SUM(CASE WHEN data_vencimento<@DataBase THEN valor-valor_recebido ELSE 0 END) AS saldo_vencido
FROM estudo.titulos;
-- 10: estoque; o saldo inicial é um movimento de Entrada
SELECT id_produto,SUM(CASE WHEN tipo=N'Entrada' THEN peso_kg ELSE -peso_kg END) AS saldo_kg
FROM estudo.movimentos_estoque WHERE data_movimento<=@DataBase GROUP BY id_produto;
-- 11: frete correto nos dois grãos de análise
SELECT SUM(frete_total) AS frete_por_pedido FROM estudo.pedidos WHERE status=N'Faturado';
SELECT SUM(i.frete_rateado) AS frete_por_item FROM estudo.itens_pedido i JOIN estudo.pedidos p ON p.id_pedido=i.id_pedido WHERE p.status=N'Faturado';
